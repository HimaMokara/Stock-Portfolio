import React from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { StockList } from './components/StockList';
import { AddStockForm } from './components/AddStockForm';

function App() {
  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Portfolio Tracker</h1>
        <Dashboard />
        <div className="mt-8">
          <AddStockForm />
        </div>
        <div className="mt-8">
          <StockList />
        </div>
      </div>
    </Layout>
  );
}

export default App;