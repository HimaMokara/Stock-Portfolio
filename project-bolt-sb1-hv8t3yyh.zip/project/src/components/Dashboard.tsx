import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, PieChart } from 'lucide-react';

export function Dashboard() {
  const metrics = {
    totalValue: 10000,
    totalGainLoss: 500,
    gainLossPercentage: 5,
  };

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
      <DashboardCard
        title="Total Value"
        value={`$${metrics.totalValue.toLocaleString()}`}
        icon={<DollarSign className="h-6 w-6 text-indigo-600" />}
      />
      <DashboardCard
        title="Total Gain/Loss"
        value={`${metrics.totalGainLoss >= 0 ? '+' : ''}$${metrics.totalGainLoss.toLocaleString()}`}
        subValue={`${metrics.gainLossPercentage}%`}
        icon={metrics.totalGainLoss >= 0 ? 
          <TrendingUp className="h-6 w-6 text-green-600" /> :
          <TrendingDown className="h-6 w-6 text-red-600" />}
        valueColor={metrics.totalGainLoss >= 0 ? 'text-green-600' : 'text-red-600'}
      />
      <DashboardCard
        title="Portfolio Distribution"
        value="5 Stocks"
        icon={<PieChart className="h-6 w-6 text-indigo-600" />}
      />
    </div>
  );
}

function DashboardCard({ 
  title, 
  value, 
  subValue, 
  icon, 
  valueColor = 'text-gray-900' 
}: { 
  title: string;
  value: string;
  subValue?: string;
  icon: React.ReactNode;
  valueColor?: string;
}) {
  return (
    <div className="bg-white overflow-hidden shadow rounded-lg">
      <div className="p-5">
        <div className="flex items-center">
          <div className="flex-shrink-0">{icon}</div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">{title}</dt>
              <dd className="flex items-baseline">
                <div className={`text-2xl font-semibold ${valueColor}`}>{value}</div>
                {subValue && (
                  <div className="ml-2 flex items-baseline text-sm font-semibold">
                    {subValue}
                  </div>
                )}
              </dd>
            </dl>
          </div>
        </div>
      </div>
    </div>
  );
}